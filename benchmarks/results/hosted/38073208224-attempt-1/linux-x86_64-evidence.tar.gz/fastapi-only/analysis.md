# Recorded benchmark analysis

Status: **partial_category_subset**. All metric cells use reference / Rust values from matching valid repetitions.

Scope: selected http1; omitted http2, http3, websocket, lifecycle. A selected subset is not a complete matrix.

| Category | Status | Rows / invalid | Qualified pairs | Evidence |
| --- | --- | ---: | ---: | --- |
| http1 | qualified_local_pairs | 40 / 0 | 4 | recorded frozen checkout evidence; no compilation attestation inferred |
| http2 | not_selected | 0 / 0 | 0 | not selected in this run |
| http3 | not_selected | 0 / 0 | 0 | not selected in this run |
| websocket | not_selected | 0 / 0 | 0 | not selected in this run |
| lifecycle | not_selected | 0 / 0 | 0 | not selected in this run |

## Matched throughput and latency

HTTP rate is requests/s; WebSocket rate is completed messages/s or handshakes/s. Latency cells are p50 / p95 / p99 in ms, separately for each server.

| Category / workload / loop | Pairs | Rate ref / Rust | Latency ref | Latency Rust | Rust/ref rate |
| --- | ---: | ---: | --- | --- | ---: |
| http1 / fastapi-validated-route / asyncio | 5 | 5,181.2 / 3,545.0 | 12.292 / 13.209 / 13.654 | 19.057 / 24.851 / 28.760 | 0.684 |
| http1 / fastapi-validated-route / uvloop | 5 | 5,151.0 / 4,017.8 | 12.259 / 12.936 / 24.020 | 16.907 / 21.588 / 23.412 | 0.774 |
| http1 / fastapi-python-cpu / asyncio | 5 | 504.5 / 471.5 | 125.2 / 146.3 / 162.0 | 139.4 / 202.9 / 209.0 | 0.935 |
| http1 / fastapi-python-cpu / uvloop | 5 | 510.9 / 482.5 | 120.4 / 152.6 / 250.5 | 134.7 / 204.9 / 211.4 | 0.936 |

## Matched resource metrics

Server CPU is observed live process-tree CPU µs/op over its recorded boundary. Client CPU is complete reaped-child CPU µs/op only when explicitly marked. RSS cells are medians of sampled peak MiB.

| Category / workload / loop | Server CPU µs/op ref / Rust | Server RSS ref / Rust | Client CPU µs/op ref / Rust | Client RSS ref / Rust |
| --- | ---: | ---: | ---: | ---: |
| http1 / fastapi-validated-route / asyncio | 192.1 / 344.4 | 47.559 / 47.637 | 67.889 / 69.667 | 12.938 / 13.070 |
| http1 / fastapi-validated-route / uvloop | 193.6 / 299.1 | 50.332 / 50.285 | 72.225 / 68.468 | 12.934 / 13.098 |
| http1 / fastapi-python-cpu / asyncio | 2,055.7 / 2,282.8 | 50.316 / 50.469 | 86.293 / 82.170 | 12.598 / 12.676 |
| http1 / fastapi-python-cpu / uvloop | 2,027.0 / 2,213.6 | 53.031 / 52.914 | 79.086 / 81.075 | 12.578 / 12.621 |

## Lifecycle

Startup is a preparation-to-observed-response upper bound. CPU is complete reaped-server lifetime seconds, with idle and active phases kept separate.

| Loop | Pairs | Startup ms ref / Rust | Idle exit ms ref / Rust | Held exit ms ref / Rust | Idle CPU s ref / Rust | Active CPU s ref / Rust | Idle RSS MiB ref / Rust | Active RSS MiB ref / Rust |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| No qualified matching lifecycle pairs | — | — | — | — | — | — | — | — |

## Exclusions and incomplete inputs


## Interpretation limits

- Three valid matching repetitions are a descriptive gate, not evidence of statistical significance.
- Medians of per-run latency percentiles are not pooled request latency percentiles.
- Throughput ratios use matching repetitions only; no overall winner or cross-protocol ranking is produced.
- Recorded H1, H2, H3, and WebSocket client clocks/setup/drain boundaries differ and cannot be compared across protocols.
- Closed-loop same-host load has no coordinated-omission correction or open-loop offered-rate evidence.
- Sustained server CPU is observed live process-tree cpu_times deltas over the recorded load/monitor boundary; complete reaped-child accounting is not inferred.
- Client CPU is complete reaped-child RUSAGE_CHILDREN accounting across setup/load/drain/report only when each row explicitly asserts client_cpu_complete.
- RSS is sampled process-tree RSS; the reported value is a median of matched runs' sampled peaks, not allocator peak, PSS, or private memory.
- Lifecycle complete CPU covers the spawned and reaped server process lifetime (startup/readiness/shutdown); the separate elapsed and cold-start boundaries additionally include observer/free-port/environment preparation, and differ from sustained request CPU.
- Lifecycle startup is preparation-to-observed-valid-response, an upper bound affected by polling and observer work; no sub-poll precision is claimed.
- Exception diagnostic policies differ and exception-to-500 timing remains unrankable; H3 uploads have no live qualifying Hypercorn performance pair.
- The analyzer checks recorded identities and gates; it does not independently attest compilation or reconstruct the measured processes.
