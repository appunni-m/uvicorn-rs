# Recorded benchmark analysis

Status: **partial_category_subset**. All metric cells use reference / Rust values from matching valid repetitions.

Scope: selected http1; omitted http2, http3, websocket, lifecycle. A selected subset is not a complete matrix.

| Category | Status | Rows / invalid | Qualified pairs | Evidence |
| --- | --- | ---: | ---: | --- |
| http1 | qualified_local_pairs | 40 / 0 | 4 | recorded frozen checkout evidence; no compilation attestation inferred |
| http2 | not_selected | 0 / 0 | 0 | not selected in this run |
| http3 | not_selected | 0 / 0 | 0 | not selected in this run |
| websocket | not_selected | 0 / 0 | 0 | not selected in this run |
| lifecycle | not_selected | 0 / 0 | 0 | not selected in this run |

## Matched throughput and latency

HTTP rate is requests/s; WebSocket rate is completed messages/s or handshakes/s. Latency cells are p50 / p95 / p99 in ms, separately for each server.

| Category / workload / loop | Pairs | Rate ref / Rust | Latency ref | Latency Rust | Rust/ref rate |
| --- | ---: | ---: | --- | --- | ---: |
| http1 / fastapi-validated-route / asyncio | 5 | 9,015.4 / 6,097.6 | 6.117 / 12.078 / 17.277 | 9.574 / 19.515 / 23.397 | 0.678 |
| http1 / fastapi-validated-route / uvloop | 5 | 10,250.8 / 6,969.2 | 5.418 / 10.794 / 16.442 | 8.564 / 16.381 / 20.806 | 0.692 |
| http1 / fastapi-python-cpu / asyncio | 5 | 595.4 / 550.5 | 105.3 / 138.9 / 176.7 | 112.2 / 180.1 / 197.3 | 0.953 |
| http1 / fastapi-python-cpu / uvloop | 5 | 569.9 / 560.9 | 109.3 / 145.7 / 180.2 | 115.6 / 172.3 / 203.5 | 0.988 |

## Matched resource metrics

Server CPU is observed live process-tree CPU µs/op over its recorded boundary. Client CPU is complete reaped-child CPU µs/op only when explicitly marked. RSS cells are medians of sampled peak MiB.

| Category / workload / loop | Server CPU µs/op ref / Rust | Server RSS ref / Rust | Client CPU µs/op ref / Rust | Client RSS ref / Rust |
| --- | ---: | ---: | ---: | ---: |
| http1 / fastapi-validated-route / asyncio | 106.7 / 173.0 | 46.188 / 48.719 | 89.295 / 66.410 | 12.562 / 12.547 |
| http1 / fastapi-validated-route / uvloop | 95.127 / 152.2 | 49.016 / 49.359 | 73.055 / 61.379 | 12.547 / 12.578 |
| http1 / fastapi-python-cpu / asyncio | 1,729.7 / 1,904.1 | 50.594 / 51.531 | 97.829 / 77.710 | 12.516 / 12.531 |
| http1 / fastapi-python-cpu / uvloop | 1,766.5 / 1,817.4 | 52.500 / 52.766 | 89.214 / 70.093 | 12.500 / 12.484 |

## Lifecycle

Startup is a preparation-to-observed-response upper bound. CPU is complete reaped-server lifetime seconds, with idle and active phases kept separate.

| Loop | Pairs | Startup ms ref / Rust | Idle exit ms ref / Rust | Held exit ms ref / Rust | Idle CPU s ref / Rust | Active CPU s ref / Rust | Idle RSS MiB ref / Rust | Active RSS MiB ref / Rust |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| No qualified matching lifecycle pairs | — | — | — | — | — | — | — | — |

## Exclusions and incomplete inputs


## Interpretation limits

- Three valid matching repetitions are a descriptive gate, not evidence of statistical significance.
- Medians of per-run latency percentiles are not pooled request latency percentiles.
- Throughput ratios use matching repetitions only; no overall winner or cross-protocol ranking is produced.
- Recorded H1, H2, H3, and WebSocket client clocks/setup/drain boundaries differ and cannot be compared across protocols.
- Closed-loop same-host load has no coordinated-omission correction or open-loop offered-rate evidence.
- Sustained server CPU is observed live process-tree cpu_times deltas over the recorded load/monitor boundary; complete reaped-child accounting is not inferred.
- Client CPU is complete reaped-child RUSAGE_CHILDREN accounting across setup/load/drain/report only when each row explicitly asserts client_cpu_complete.
- RSS is sampled process-tree RSS; the reported value is a median of matched runs' sampled peaks, not allocator peak, PSS, or private memory.
- Lifecycle complete CPU covers the spawned and reaped server process lifetime (startup/readiness/shutdown); the separate elapsed and cold-start boundaries additionally include observer/free-port/environment preparation, and differ from sustained request CPU.
- Lifecycle startup is preparation-to-observed-valid-response, an upper bound affected by polling and observer work; no sub-poll precision is claimed.
- Exception diagnostic policies differ and exception-to-500 timing remains unrankable; H3 uploads have no live qualifying Hypercorn performance pair.
- The analyzer checks recorded identities and gates; it does not independently attest compilation or reconstruct the measured processes.
