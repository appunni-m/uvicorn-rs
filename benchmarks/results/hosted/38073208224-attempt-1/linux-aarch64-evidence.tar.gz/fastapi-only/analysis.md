# Recorded benchmark analysis

Status: **partial_category_subset**. All metric cells use reference / Rust values from matching valid repetitions.

Scope: selected http1; omitted http2, http3, websocket, lifecycle. A selected subset is not a complete matrix.

| Category | Status | Rows / invalid | Qualified pairs | Evidence |
| --- | --- | ---: | ---: | --- |
| http1 | qualified_local_pairs | 40 / 1 | 4 | recorded frozen checkout evidence; no compilation attestation inferred |
| http2 | not_selected | 0 / 0 | 0 | not selected in this run |
| http3 | not_selected | 0 / 0 | 0 | not selected in this run |
| websocket | not_selected | 0 / 0 | 0 | not selected in this run |
| lifecycle | not_selected | 0 / 0 | 0 | not selected in this run |

## Matched throughput and latency

HTTP rate is requests/s; WebSocket rate is completed messages/s or handshakes/s. Latency cells are p50 / p95 / p99 in ms, separately for each server.

| Category / workload / loop | Pairs | Rate ref / Rust | Latency ref | Latency Rust | Rust/ref rate |
| --- | ---: | ---: | --- | --- | ---: |
| http1 / fastapi-validated-route / asyncio | 4 | 5,339.9 / 4,418.0 | 11.902 / 12.630 / 12.965 | 14.991 / 18.377 / 20.201 | 0.821 |
| http1 / fastapi-validated-route / uvloop | 5 | 5,385.2 / 5,063.4 | 11.840 / 12.236 / 12.606 | 12.948 / 15.968 / 18.341 | 0.946 |
| http1 / fastapi-python-cpu / asyncio | 5 | 500.1 / 484.1 | 127.1 / 144.2 / 153.0 | 133.7 / 198.8 / 203.8 | 0.970 |
| http1 / fastapi-python-cpu / uvloop | 5 | 514.7 / 497.2 | 122.6 / 140.8 / 251.2 | 121.8 / 156.6 / 200.4 | 0.970 |

## Matched resource metrics

Server CPU is observed live process-tree CPU µs/op over its recorded boundary. Client CPU is complete reaped-child CPU µs/op only when explicitly marked. RSS cells are medians of sampled peak MiB.

| Category / workload / loop | Server CPU µs/op ref / Rust | Server RSS ref / Rust | Client CPU µs/op ref / Rust | Client RSS ref / Rust |
| --- | ---: | ---: | ---: | ---: |
| http1 / fastapi-validated-route / asyncio | 187.0 / 257.2 | 47.502 / 48.096 | 27.835 / 27.259 | 12.320 / 12.410 |
| http1 / fastapi-validated-route / uvloop | 185.3 / 222.0 | 49.766 / 50.039 | 28.401 / 26.949 | 12.324 / 12.531 |
| http1 / fastapi-python-cpu / asyncio | 2,031.6 / 2,135.9 | 50.379 / 51.238 | 53.321 / 51.914 | 11.941 / 11.961 |
| http1 / fastapi-python-cpu / uvloop | 1,964.8 / 2,050.0 | 52.352 / 53.148 | 52.180 / 49.065 | 11.961 / 11.965 |

## Lifecycle

Startup is a preparation-to-observed-response upper bound. CPU is complete reaped-server lifetime seconds, with idle and active phases kept separate.

| Loop | Pairs | Startup ms ref / Rust | Idle exit ms ref / Rust | Held exit ms ref / Rust | Idle CPU s ref / Rust | Active CPU s ref / Rust | Idle RSS MiB ref / Rust | Active RSS MiB ref / Rust |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| No qualified matching lifecycle pairs | — | — | — | — | — | — | — | — |

## Exclusions and incomplete inputs

- http1 invalid row reasons: timing_valid_false_or_missing=1; unrelated_host_cpu_activity=1.

## Interpretation limits

- Three valid matching repetitions are a descriptive gate, not evidence of statistical significance.
- Medians of per-run latency percentiles are not pooled request latency percentiles.
- Throughput ratios use matching repetitions only; no overall winner or cross-protocol ranking is produced.
- Recorded H1, H2, H3, and WebSocket client clocks/setup/drain boundaries differ and cannot be compared across protocols.
- Closed-loop same-host load has no coordinated-omission correction or open-loop offered-rate evidence.
- Sustained server CPU is observed live process-tree cpu_times deltas over the recorded load/monitor boundary; complete reaped-child accounting is not inferred.
- Client CPU is complete reaped-child RUSAGE_CHILDREN accounting across setup/load/drain/report only when each row explicitly asserts client_cpu_complete.
- RSS is sampled process-tree RSS; the reported value is a median of matched runs' sampled peaks, not allocator peak, PSS, or private memory.
- Lifecycle complete CPU covers the spawned and reaped server process lifetime (startup/readiness/shutdown); the separate elapsed and cold-start boundaries additionally include observer/free-port/environment preparation, and differ from sustained request CPU.
- Lifecycle startup is preparation-to-observed-valid-response, an upper bound affected by polling and observer work; no sub-poll precision is claimed.
- Exception diagnostic policies differ and exception-to-500 timing remains unrankable; H3 uploads have no live qualifying Hypercorn performance pair.
- The analyzer checks recorded identities and gates; it does not independently attest compilation or reconstruct the measured processes.
