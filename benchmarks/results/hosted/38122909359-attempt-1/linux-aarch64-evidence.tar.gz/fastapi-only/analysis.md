# Recorded benchmark analysis

Status: **partial_category_subset**. All metric cells use reference / Rust values from matching valid repetitions.

Scope: selected http1; omitted http2, http3, websocket, lifecycle. A selected subset is not a complete matrix.

| Category | Status | Rows / invalid | Qualified pairs | Evidence |
| --- | --- | ---: | ---: | --- |
| http1 | qualified_local_pairs | 40 / 1 | 4 | recorded frozen checkout evidence; no compilation attestation inferred |
| http2 | not_selected | 0 / 0 | 0 | not selected in this run |
| http3 | not_selected | 0 / 0 | 0 | not selected in this run |
| websocket | not_selected | 0 / 0 | 0 | not selected in this run |
| lifecycle | not_selected | 0 / 0 | 0 | not selected in this run |

## Matched throughput and latency

HTTP rate is requests/s; WebSocket rate is completed messages/s or handshakes/s. Latency cells are p50 / p95 / p99 in ms, separately for each server.

| Category / workload / loop | Pairs | Rate ref / Rust | Latency ref | Latency Rust | Rust/ref rate |
| --- | ---: | ---: | --- | --- | ---: |
| http1 / fastapi-validated-route / asyncio | 4 | 5,222.8 / 4,017.4 | 12.177 / 12.774 / 13.173 | 16.524 / 20.373 / 22.975 | 0.769 |
| http1 / fastapi-validated-route / uvloop | 5 | 5,082.1 / 4,755.8 | 12.461 / 12.995 / 13.224 | 13.861 / 17.172 / 18.477 | 0.936 |
| http1 / fastapi-python-cpu / asyncio | 5 | 479.5 / 465.9 | 132.7 / 151.4 / 163.6 | 139.3 / 206.5 / 214.2 | 0.963 |
| http1 / fastapi-python-cpu / uvloop | 5 | 483.8 / 479.7 | 133.4 / 141.7 / 281.5 | 137.9 / 163.3 / 203.8 | 0.989 |

## Matched resource metrics

Server CPU is observed live process-tree CPU µs/op over its recorded boundary. Client CPU is complete reaped-child CPU µs/op only when explicitly marked. RSS cells are medians of sampled peak MiB.

| Category / workload / loop | Server CPU µs/op ref / Rust | Server RSS ref / Rust | Client CPU µs/op ref / Rust | Client RSS ref / Rust |
| --- | ---: | ---: | ---: | ---: |
| http1 / fastapi-validated-route / asyncio | 191.2 / 287.3 | 47.492 / 48.082 | 35.854 / 36.020 | 12.318 / 12.438 |
| http1 / fastapi-validated-route / uvloop | 196.3 / 239.1 | 49.766 / 50.047 | 35.463 / 35.989 | 12.277 / 12.461 |
| http1 / fastapi-python-cpu / asyncio | 2,117.5 / 2,245.0 | 50.344 / 51.094 | 68.410 / 70.709 | 11.957 / 11.957 |
| http1 / fastapi-python-cpu / uvloop | 2,089.1 / 2,153.7 | 52.164 / 53.105 | 68.030 / 65.236 | 11.961 / 11.969 |

## Lifecycle

Startup is a preparation-to-observed-response upper bound. CPU is complete reaped-server lifetime seconds, with idle and active phases kept separate.

| Loop | Pairs | Startup ms ref / Rust | Idle exit ms ref / Rust | Held exit ms ref / Rust | Idle CPU s ref / Rust | Active CPU s ref / Rust | Idle RSS MiB ref / Rust | Active RSS MiB ref / Rust |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| No qualified matching lifecycle pairs | — | — | — | — | — | — | — | — |

## Exclusions and incomplete inputs

- http1 invalid row reasons: timing_valid_false_or_missing=1; unrelated_host_cpu_activity=1.

## Interpretation limits

- Three valid matching repetitions are a descriptive gate, not evidence of statistical significance.
- Medians of per-run latency percentiles are not pooled request latency percentiles.
- Throughput ratios use matching repetitions only; no overall winner or cross-protocol ranking is produced.
- Recorded H1, H2, H3, and WebSocket client clocks/setup/drain boundaries differ and cannot be compared across protocols.
- Closed-loop same-host load has no coordinated-omission correction or open-loop offered-rate evidence.
- Sustained server CPU is observed live process-tree cpu_times deltas over the recorded load/monitor boundary; complete reaped-child accounting is not inferred.
- Client CPU is complete reaped-child RUSAGE_CHILDREN accounting across setup/load/drain/report only when each row explicitly asserts client_cpu_complete.
- RSS is sampled process-tree RSS; the reported value is a median of matched runs' sampled peaks, not allocator peak, PSS, or private memory.
- Lifecycle complete CPU covers the spawned and reaped server process lifetime (startup/readiness/shutdown); the separate elapsed and cold-start boundaries additionally include observer/free-port/environment preparation, and differ from sustained request CPU.
- Lifecycle startup is preparation-to-observed-valid-response, an upper bound affected by polling and observer work; no sub-poll precision is claimed.
- Exception diagnostic policies differ and exception-to-500 timing remains unrankable; H3 uploads have no live qualifying Hypercorn performance pair.
- The analyzer checks recorded identities and gates; it does not independently attest compilation or reconstruct the measured processes.
