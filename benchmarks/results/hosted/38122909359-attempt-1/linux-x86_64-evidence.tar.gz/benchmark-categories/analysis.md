# Recorded benchmark analysis

Status: **incomplete_categories**. All metric cells use reference / Rust values from matching valid repetitions.

Scope: selected http1, http2, http3, websocket, lifecycle; omitted none. A selected subset is not a complete matrix.

| Category | Status | Rows / invalid | Qualified pairs | Evidence |
| --- | --- | ---: | ---: | --- |
| http1 | qualified_local_pairs | 300 / 0 | 30 | recorded frozen checkout evidence; no compilation attestation inferred |
| http2 | incomplete_category | 19 / 0 | 0 | recorded frozen checkout evidence; no compilation attestation inferred |
| http3 | qualified_local_pairs | 130 / 1 | 12 | recorded frozen checkout evidence; no compilation attestation inferred |
| websocket | qualified_local_pairs | 60 / 0 | 6 | recorded frozen checkout evidence; no compilation attestation inferred |
| lifecycle | qualified_local_pairs | 20 / 0 | 2 | recorded frozen checkout evidence; no compilation attestation inferred |

## Matched throughput and latency

HTTP rate is requests/s; WebSocket rate is completed messages/s or handshakes/s. Latency cells are p50 / p95 / p99 in ms, separately for each server.

| Category / workload / loop | Pairs | Rate ref / Rust | Latency ref | Latency Rust | Rust/ref rate |
| --- | ---: | ---: | --- | --- | ---: |
| http1 / fastapi-validated-route / asyncio | 5 | 5,377.7 / 3,688.4 | 11.769 / 13.452 / 13.968 | 18.434 / 23.848 / 27.210 | 0.688 |
| http1 / fastapi-validated-route / uvloop | 5 | 5,550.6 / 4,102.0 | 11.326 / 12.222 / 22.541 | 16.038 / 21.252 / 23.464 | 0.736 |
| http1 / fastapi-fixed / asyncio | 5 | 7,061.2 / 4,909.4 | 9.168 / 9.682 / 9.792 | 13.337 / 18.474 / 19.976 | 0.694 |
| http1 / fastapi-fixed / uvloop | 5 | 7,462.6 / 5,680.9 | 8.667 / 9.377 / 16.866 | 11.238 / 15.498 / 16.525 | 0.762 |
| http1 / fastapi-large-response / asyncio | 5 | 2,724.7 / 2,429.9 | 23.868 / 25.827 / 30.027 | 26.769 / 34.971 / 36.382 | 0.892 |
| http1 / fastapi-large-response / uvloop | 5 | 2,785.8 / 2,640.1 | 22.294 / 24.712 / 45.219 | 24.655 / 32.698 / 34.205 | 0.959 |
| http1 / fastapi-many-response-chunks / asyncio | 5 | 256.4 / 363.5 | 246.4 / 274.5 / 292.2 | 173.2 / 205.2 / 212.5 | 1.418 |
| http1 / fastapi-many-response-chunks / uvloop | 5 | 269.4 / 503.5 | 196.2 / 253.0 / 2,358.2 | 122.6 / 152.3 / 160.4 | 1.875 |
| http1 / fastapi-small-response-chunks / asyncio | 5 | 529.4 / 699.6 | 120.9 / 134.5 / 142.6 | 105.0 / 117.5 / 122.0 | 1.311 |
| http1 / fastapi-small-response-chunks / uvloop | 5 | 540.6 / 1,032.1 | 115.8 / 133.2 / 624.3 | 59.125 / 96.886 / 104.0 | 1.911 |
| http1 / fastapi-request-upload / asyncio | 5 | 1,270.8 / 373.8 | 49.708 / 57.851 / 66.474 | 167.6 / 223.4 / 257.5 | 0.295 |
| http1 / fastapi-request-upload / uvloop | 5 | 1,381.8 / 604.9 | 45.763 / 49.794 / 53.120 | 105.6 / 115.6 / 138.2 | 0.438 |
| http1 / fastapi-upload-1m-write-1k / asyncio | 5 | 433.6 / 271.6 | 148.9 / 171.6 / 188.2 | 230.3 / 289.2 / 411.6 | 0.620 |
| http1 / fastapi-upload-1m-write-1k / uvloop | 5 | 436.0 / 360.8 | 140.0 / 183.3 / 376.0 | 166.7 / 198.9 / 350.6 | 0.828 |
| http1 / fastapi-upload-1m-write-16k / asyncio | 5 | 1,130.4 / 371.1 | 55.679 / 63.644 / 69.199 | 168.6 / 209.1 / 258.6 | 0.326 |
| http1 / fastapi-upload-1m-write-16k / uvloop | 5 | 1,309.8 / 608.8 | 48.186 / 55.906 / 214.6 | 104.6 / 115.7 / 134.0 | 0.462 |
| http1 / fastapi-upload-1m-write-256k / asyncio | 5 | 1,244.3 / 374.8 | 50.664 / 58.198 / 66.318 | 168.0 / 225.6 / 247.8 | 0.301 |
| http1 / fastapi-upload-1m-write-256k / uvloop | 5 | 1,353.4 / 603.0 | 46.741 / 49.181 / 52.521 | 105.8 / 114.9 / 138.8 | 0.445 |
| http1 / fastapi-upload-1m-write-1m / asyncio | 5 | 1,244.9 / 375.8 | 50.653 / 58.018 / 65.346 | 167.6 / 228.0 / 247.1 | 0.296 |
| http1 / fastapi-upload-1m-write-1m / uvloop | 5 | 1,383.0 / 601.1 | 45.649 / 50.321 / 54.373 | 106.2 / 115.5 / 133.8 | 0.437 |
| http1 / fastapi-request-upload-small-chunks / asyncio | 5 | 2,918.4 / 1,310.3 | 21.502 / 24.978 / 27.046 | 49.643 / 59.627 / 71.986 | 0.446 |
| http1 / fastapi-request-upload-small-chunks / uvloop | 5 | 2,820.9 / 1,750.4 | 21.628 / 27.499 / 44.698 | 37.012 / 45.522 / 53.512 | 0.619 |
| http1 / fastapi-slow-reader-backpressure / asyncio | 5 | 31.632 / 31.685 | 251.2 / 257.3 / 268.7 | 251.4 / 254.6 / 263.4 | 1.002 |
| http1 / fastapi-slow-reader-backpressure / uvloop | 5 | 31.650 / 31.682 | 251.2 / 257.6 / 267.5 | 251.4 / 255.3 / 263.5 | 1.001 |
| http1 / fastapi-scope-32-headers / asyncio | 5 | 5,797.1 / 4,507.3 | 11.263 / 12.064 / 12.144 | 14.808 / 19.389 / 22.788 | 0.787 |
| http1 / fastapi-scope-32-headers / uvloop | 5 | 5,969.4 / 4,881.3 | 10.761 / 11.110 / 21.497 | 13.521 / 17.833 / 18.609 | 0.823 |
| http1 / fastapi-contextvars / asyncio | 5 | 6,713.5 / 4,133.6 | 9.339 / 10.366 / 11.211 | 16.298 / 21.636 / 23.983 | 0.609 |
| http1 / fastapi-contextvars / uvloop | 5 | 6,154.9 / 4,687.0 | 9.892 / 11.131 / 21.492 | 13.838 / 18.679 / 19.519 | 0.761 |
| http1 / fastapi-python-cpu / asyncio | 5 | 507.3 / 475.1 | 125.0 / 143.9 / 159.5 | 136.5 / 204.0 / 209.2 | 0.938 |
| http1 / fastapi-python-cpu / uvloop | 5 | 518.2 / 484.5 | 120.5 / 152.7 / 241.6 | 134.5 / 202.3 / 212.9 | 0.936 |
| http3 / protocol-scope-consumed-request / asyncio | 5 | 1,105.6 / 1,809.2 | 0.916 / 1.054 / 1.234 | 0.547 / 0.620 / 0.652 | 1.635 |
| http3 / protocol-scope-consumed-request / uvloop | 5 | 1,151.0 / 2,046.7 | 0.876 / 1.030 / 1.153 | 0.482 / 0.553 / 0.583 | 1.781 |
| http3 / protocol-scope / asyncio | 5 | 1,118.0 / 2,433.4 | 0.911 / 1.025 / 1.122 | 0.407 / 0.462 / 0.491 | 2.172 |
| http3 / protocol-scope / uvloop | 5 | 1,176.5 / 2,581.0 | 0.852 / 1.003 / 1.137 | 0.385 / 0.438 / 0.464 | 2.194 |
| http3 / fixed / asyncio | 5 | 1,127.7 / 2,440.5 | 0.907 / 1.023 / 1.113 | 0.406 / 0.460 / 0.490 | 2.174 |
| http3 / fixed / uvloop | 5 | 1,190.9 / 2,597.1 | 0.843 / 1.007 / 1.129 | 0.381 / 0.434 / 0.465 | 2.191 |
| http3 / large-response / asyncio | 4 | 13.838 / 335.5 | 88.050 / 103.2 / 109.5 | 2.838 / 3.231 / 4.168 | 24.339 |
| http3 / large-response / uvloop | 5 | 17.892 / 339.2 | 55.850 / 57.695 / 60.501 | 2.805 / 3.198 / 4.159 | 18.964 |
| http3 / many-response-chunks / asyncio | 5 | 11.292 / 242.5 | 88.498 / 94.126 / 98.098 | 4.058 / 4.756 / 5.370 | 21.474 |
| http3 / many-response-chunks / uvloop | 5 | 12.225 / 260.9 | 81.958 / 87.762 / 97.335 | 3.782 / 4.397 / 5.334 | 21.396 |
| http3 / slow-reader-backpressure / asyncio | 5 | 7.921 / 7.949 | 251.7 / 253.2 / 254.1 | 251.5 / 252.1 / 252.5 | 1.003 |
| http3 / slow-reader-backpressure / uvloop | 5 | 7.932 / 7.953 | 251.7 / 253.4 / 254.9 | 251.3 / 252.2 / 252.9 | 1.003 |
| websocket / connection-handshake / asyncio | 5 | 1,260.4 / 1,547.1 | 0.734 / 0.947 / 1.115 | 0.628 / 0.705 / 0.735 | 1.225 |
| websocket / connection-handshake / uvloop | 5 | 1,434.4 / 1,825.2 | 0.636 / 0.841 / 1.127 | 0.524 / 0.607 / 0.626 | 1.279 |
| websocket / text-echo / asyncio | 5 | 17,247.8 / 6,988.7 | 4.245 / 4.604 / 4.960 | 9.535 / 11.266 / 13.242 | 0.405 |
| websocket / text-echo / uvloop | 5 | 19,130.0 / 12,107.9 | 3.893 / 4.335 / 4.623 | 5.540 / 6.678 / 8.049 | 0.633 |
| websocket / binary-64k-echo / asyncio | 5 | 9,191.7 / 5,860.7 | 6.811 / 8.504 / 9.869 | 11.830 / 14.423 / 15.797 | 0.636 |
| websocket / binary-64k-echo / uvloop | 5 | 11,105.0 / 8,637.1 | 5.128 / 7.117 / 8.177 | 7.831 / 9.426 / 10.789 | 0.769 |

## Matched resource metrics

Server CPU is observed live process-tree CPU µs/op over its recorded boundary. Client CPU is complete reaped-child CPU µs/op only when explicitly marked. RSS cells are medians of sampled peak MiB.

| Category / workload / loop | Server CPU µs/op ref / Rust | Server RSS ref / Rust | Client CPU µs/op ref / Rust | Client RSS ref / Rust |
| --- | ---: | ---: | ---: | ---: |
| http1 / fastapi-validated-route / asyncio | 185.5 / 327.5 | 47.508 / 47.738 | 63.162 / 59.546 | 12.977 / 13.070 |
| http1 / fastapi-validated-route / uvloop | 179.7 / 289.1 | 50.375 / 50.395 | 62.368 / 58.042 | 12.953 / 13.090 |
| http1 / fastapi-fixed / asyncio | 141.2 / 255.3 | 47.457 / 47.582 | 68.581 / 56.794 | 12.855 / 12.863 |
| http1 / fastapi-fixed / uvloop | 133.7 / 214.8 | 50.281 / 50.422 | 67.492 / 55.583 | 12.848 / 13.020 |
| http1 / fastapi-large-response / asyncio | 366.0 / 538.9 | 48.508 / 48.547 | 324.5 / 342.4 | 14.602 / 14.598 |
| http1 / fastapi-large-response / uvloop | 358.0 / 490.6 | 51.301 / 51.250 | 321.9 / 338.9 | 14.664 / 14.551 |
| http1 / fastapi-many-response-chunks / asyncio | 3,898.3 / 4,307.1 | 49.430 / 49.734 | 2,149.8 / 671.5 | 14.512 / 14.453 |
| http1 / fastapi-many-response-chunks / uvloop | 3,707.6 / 2,948.1 | 52.691 / 52.312 | 2,034.7 / 633.8 | 14.562 / 14.617 |
| http1 / fastapi-small-response-chunks / asyncio | 1,884.4 / 1,963.3 | 49.457 / 49.668 | 1,000.6 / 173.1 | 13.121 / 13.707 |
| http1 / fastapi-small-response-chunks / uvloop | 1,845.7 / 1,337.3 | 52.730 / 52.508 | 981.8 / 153.3 | 13.078 / 13.664 |
| http1 / fastapi-request-upload / asyncio | 783.2 / 3,990.5 | 107.9 / 121.4 | 533.6 / 435.8 | 21.121 / 21.121 |
| http1 / fastapi-request-upload / uvloop | 722.0 / 2,500.8 | 107.3 / 121.8 | 464.4 / 421.4 | 21.043 / 21.102 |
| http1 / fastapi-upload-1m-write-1k / asyncio | 1,195.3 / 3,808.1 | 101.8 / 121.3 | 7,133.5 / 5,788.1 | 14.562 / 14.516 |
| http1 / fastapi-upload-1m-write-1k / uvloop | 1,112.1 / 2,277.1 | 105.3 / 122.0 | 6,988.2 / 5,758.6 | 14.539 / 14.434 |
| http1 / fastapi-upload-1m-write-16k / asyncio | 843.2 / 3,928.8 | 105.6 / 121.7 | 886.8 / 695.5 | 16.312 / 16.223 |
| http1 / fastapi-upload-1m-write-16k / uvloop | 740.3 / 2,407.2 | 124.3 / 122.1 | 929.7 / 700.8 | 16.371 / 16.324 |
| http1 / fastapi-upload-1m-write-256k / asyncio | 795.1 / 3,985.4 | 105.6 / 122.5 | 536.5 / 437.4 | 21.125 / 21.062 |
| http1 / fastapi-upload-1m-write-256k / uvloop | 736.7 / 2,505.8 | 106.8 / 119.3 | 469.9 / 422.3 | 21.059 / 21.105 |
| http1 / fastapi-upload-1m-write-1m / asyncio | 798.7 / 3,975.8 | 108.7 / 123.0 | 534.7 / 439.7 | 21.105 / 21.102 |
| http1 / fastapi-upload-1m-write-1m / uvloop | 720.8 / 2,518.1 | 107.5 / 118.7 | 464.1 / 422.0 | 21.082 / 21.055 |
| http1 / fastapi-request-upload-small-chunks / asyncio | 276.0 / 890.4 | 50.590 / 62.230 | 707.7 / 708.1 | 13.637 / 13.566 |
| http1 / fastapi-request-upload-small-chunks / uvloop | 287.0 / 628.6 | 54.590 / 64.785 | 712.5 / 703.6 | 13.660 / 13.660 |
| http1 / fastapi-slow-reader-backpressure / asyncio | 2,125.0 / 2,062.5 | 47.562 / 45.387 | 4,291.9 / 3,902.4 | 92.441 / 92.516 |
| http1 / fastapi-slow-reader-backpressure / uvloop | 2,062.5 / 1,875.0 | 50.430 / 48.066 | 4,063.7 / 3,854.8 | 92.199 / 92.797 |
| http1 / fastapi-scope-32-headers / asyncio | 172.5 / 274.7 | 47.871 / 47.762 | 82.354 / 69.699 | 13.594 / 13.898 |
| http1 / fastapi-scope-32-headers / uvloop | 167.5 / 249.2 | 50.668 / 50.504 | 82.566 / 69.106 | 13.562 / 13.973 |
| http1 / fastapi-contextvars / asyncio | 149.0 / 295.7 | 47.547 / 47.680 | 56.116 / 57.400 | 12.840 / 12.770 |
| http1 / fastapi-contextvars / uvloop | 162.0 / 256.2 | 50.352 / 50.398 | 63.429 / 56.488 | 12.852 / 12.941 |
| http1 / fastapi-python-cpu / asyncio | 2,049.8 / 2,262.1 | 50.258 / 50.441 | 78.922 / 71.168 | 12.602 / 12.652 |
| http1 / fastapi-python-cpu / uvloop | 2,000.8 / 2,195.7 | 53.047 / 52.930 | 73.825 / 71.566 | 12.578 / 12.562 |
| http3 / protocol-scope-consumed-request / asyncio | 904.3 / 513.1 | 110.5 / 46.516 | 256.1 / 136.9 | 5.734 / 5.719 |
| http3 / protocol-scope-consumed-request / uvloop | 867.1 / 428.4 | 112.3 / 49.316 | 260.0 / 140.4 | 5.711 / 5.754 |
| http3 / protocol-scope / asyncio | 893.9 / 354.2 | 110.2 / 46.523 | 254.6 / 133.7 | 5.648 / 5.809 |
| http3 / protocol-scope / uvloop | 848.8 / 326.2 | 112.4 / 49.309 | 254.5 / 134.5 | 5.727 / 5.812 |
| http3 / fixed / asyncio | 883.7 / 353.2 | 110.3 / 46.578 | 254.5 / 135.7 | 5.699 / 5.797 |
| http3 / fixed / uvloop | 838.0 / 323.2 | 112.4 / 49.285 | 253.3 / 134.6 | 5.680 / 5.836 |
| http3 / large-response / asyncio | 45,537.3 / 2,633.4 | 114.1 / 50.727 | 15,595.6 / 3,681.7 | 7.158 / 9.252 |
| http3 / large-response / uvloop | 55,777.8 / 2,588.5 | 115.4 / 52.441 | 13,649.3 / 3,667.0 | 6.953 / 9.375 |
| http3 / many-response-chunks / asyncio | 88,596.5 / 5,538.1 | 111.0 / 49.602 | 21,508.4 / 4,630.0 | 6.703 / 8.625 |
| http3 / many-response-chunks / uvloop | 81,129.0 / 4,791.7 | 112.8 / 50.789 | 21,871.0 / 4,408.1 | 6.844 / 8.965 |
| http3 / slow-reader-backpressure / asyncio | 71,750.0 / 5,750.0 | 111.3 / 48.258 | 19,972.2 / 9,523.8 | 9.715 / 10.305 |
| http3 / slow-reader-backpressure / uvloop | 66,500.0 / 4,750.0 | 113.2 / 52.766 | 19,773.4 / 8,760.5 | 10.098 / 10.488 |
| websocket / connection-handshake / asyncio | 780.0 / 720.0 | 47.508 / 46.074 | 186.9 / 204.8 | 3.367 / 3.375 |
| websocket / connection-handshake / uvloop | 700.0 / 540.0 | 50.379 / 48.777 | 197.5 / 205.8 | 3.309 / 3.320 |
| websocket / text-echo / asyncio | 58.272 / 209.5 | 50.828 / 56.855 | 41.603 / 35.510 | 13.000 / 12.371 |
| websocket / text-echo / uvloop | 52.649 / 125.2 | 53.273 / 59.688 | 39.829 / 32.194 | 12.977 / 12.414 |
| websocket / binary-64k-echo / asyncio | 109.7 / 262.9 | 59.785 / 65.828 | 75.263 / 85.862 | 16.477 / 16.223 |
| websocket / binary-64k-echo / uvloop | 90.634 / 172.9 | 62.113 / 69.375 | 72.833 / 79.434 | 16.520 / 16.457 |

## Lifecycle

Startup is a preparation-to-observed-response upper bound. CPU is complete reaped-server lifetime seconds, with idle and active phases kept separate.

| Loop | Pairs | Startup ms ref / Rust | Idle exit ms ref / Rust | Held exit ms ref / Rust | Idle CPU s ref / Rust | Active CPU s ref / Rust | Idle RSS MiB ref / Rust | Active RSS MiB ref / Rust |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| asyncio | 5 | 306.0 / 263.3 | 199.1 / 31.513 | 2,192.1 / 2,039.6 | 0.299 / 0.288 | 0.303 / 0.292 | 44.414 / 43.031 | 44.316 / 43.133 |
| uvloop | 5 | 306.3 / 265.4 | 200.7 / 31.543 | 2,191.5 / 2,036.3 | 0.302 / 0.292 | 0.308 / 0.294 | 47.496 / 45.730 | 47.445 / 45.773 |

## Exclusions and incomplete inputs

- http2/protocol-scope/asyncio: 5 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/protocol-scope/uvloop: 4 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/fixed/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/fixed/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/large-response/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/large-response/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/many-response-chunks/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/many-response-chunks/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/request-upload/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/request-upload/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/request-upload-small-chunks/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/request-upload-small-chunks/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/slow-reader-backpressure/asyncio: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http2/slow-reader-backpressure/uvloop: 0 matching valid repetitions; category_completion_metadata_missing; category_incomplete; driver_category_clean_owned_process_exit_missing_or_failed; driver_category_correctness_gate_missing_or_failed; driver_category_exit_not_successful; driver_category_plan_or_identity_gate_missing_or_failed; driver_category_report_hash_differs_or_missing; driver_category_row_count_differs_or_missing; fewer_than_required_matching_valid_repetitions; recorded_dependency_identities_differ_or_missing; recorded_identity_not_stable_or_missing; recorded_pair_gate_missing_or_duplicate; recorded_source_native_client_identities_differ_or_missing.
- http3 invalid row reasons: timing_valid_false_or_missing=1; unrelated_host_cpu_activity=1.
- http3 target-only exclusions: {'target_only_no_live_reference_pair': 10}.
- http3/request-upload/asyncio: 0 matching valid repetitions; fewer_than_required_matching_valid_repetitions; recorded_pair_gate_missing_or_duplicate; target_only_no_live_reference_pair.
- http3/request-upload/uvloop: 0 matching valid repetitions; fewer_than_required_matching_valid_repetitions; recorded_pair_gate_missing_or_duplicate; target_only_no_live_reference_pair.

## Interpretation limits

- Three valid matching repetitions are a descriptive gate, not evidence of statistical significance.
- Medians of per-run latency percentiles are not pooled request latency percentiles.
- Throughput ratios use matching repetitions only; no overall winner or cross-protocol ranking is produced.
- Recorded H1, H2, H3, and WebSocket client clocks/setup/drain boundaries differ and cannot be compared across protocols.
- Closed-loop same-host load has no coordinated-omission correction or open-loop offered-rate evidence.
- Sustained server CPU is observed live process-tree cpu_times deltas over the recorded load/monitor boundary; complete reaped-child accounting is not inferred.
- Client CPU is complete reaped-child RUSAGE_CHILDREN accounting across setup/load/drain/report only when each row explicitly asserts client_cpu_complete.
- RSS is sampled process-tree RSS; the reported value is a median of matched runs' sampled peaks, not allocator peak, PSS, or private memory.
- Lifecycle complete CPU covers the spawned and reaped server process lifetime (startup/readiness/shutdown); the separate elapsed and cold-start boundaries additionally include observer/free-port/environment preparation, and differ from sustained request CPU.
- Lifecycle startup is preparation-to-observed-valid-response, an upper bound affected by polling and observer work; no sub-poll precision is claimed.
- Exception diagnostic policies differ and exception-to-500 timing remains unrankable; H3 uploads have no live qualifying Hypercorn performance pair.
- The analyzer checks recorded identities and gates; it does not independently attest compilation or reconstruct the measured processes.
