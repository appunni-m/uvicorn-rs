#!/usr/bin/env python3
"""Read-only inventory of repository test/server/client processes."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import psutil

ROOT=Path(__file__).resolve().parents[3]
OUTPUT=Path(__file__).resolve().parent/"repository-test-process-inventory.json"

def main():
    patterns=("scripts/run_parity.py","scripts/run_unified_coverage.py","tests/parity/","tests.parity.app","audit_normal.py","startup_probe.py","server_api_probe.py")
    found=[]
    limited=[]
    inspected=0
    for process in psutil.process_iter(["pid","ppid","create_time","status","cmdline","cwd","uids"],ad_value=None):
        info=process.info
        if info["pid"]==os.getpid():
            continue
        uids=info.get("uids")
        if uids is not None and uids.real!=os.getuid():
            continue
        argv=info.get("cmdline")
        cwd=info.get("cwd")
        if uids is not None and argv is None:
            limited.append(info["pid"])
            continue
        if not argv:
            continue
        inspected+=1
        rooted=(cwd is not None and (cwd==str(ROOT) or cwd.startswith(str(ROOT)+"/"))) or any(str(ROOT) in value for value in argv)
        if not rooted:
            continue
        test=any(marker in value for marker in patterns for value in argv) or ("-m" in argv and "uvicorn_rs" in argv) or any(value.endswith("/parity-http3") for value in argv)
        if test:
            found.append({"pid":info["pid"],"ppid":info.get("ppid"),"create_time":info.get("create_time"),"status":info.get("status"),"cwd":cwd,"argv":argv})
    receipt={"schema":"uvicorn-rs-repository-test-process-inventory@1","recorded_at":datetime.now(timezone.utc).isoformat(),"status":"passed" if not found and not limited else "limited" if not found else "live_test_processes_found","read_only":True,"repository":str(ROOT),"repository_test_processes":found,"same_user_commandlines_unavailable_pids":limited,"same_user_processes_inspected":inspected,"closed_owned_sessions":[43642,92945,11786,34677,97292],"signals_sent":0,"servers_started":0}
    OUTPUT.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))
    return 0 if receipt["status"]=="passed" else 1

if __name__=="__main__":
    raise SystemExit(main())
