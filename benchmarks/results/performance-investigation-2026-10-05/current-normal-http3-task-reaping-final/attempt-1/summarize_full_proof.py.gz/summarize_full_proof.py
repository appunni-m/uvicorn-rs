#!/usr/bin/env python3
"""Summarize one completed measurement without aggregating earlier attempts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
PROOF=ROOT/"build/asgi-coverage/unified-http3-owned-request-drain-451-2026-10-05"
REPORT=PROOF/"full-attempt-2/coverage-report.json"
OUTPUT=PROOF/"full-proof-receipt.json"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    extension=json.loads(REPORT.read_text())["uvicorn_rs_unified"]
    matrix=extension["matrix"]
    coverage=extension["coverage"]
    frozen=json.loads((PROOF/"frozen-451-identity.json").read_text())["source_identity"]
    ids={"fault.http3.connection-accept-error","fault.http3.connection-accept-error-aborts-held-response","http3.sequential-responses-one-connection","http3.peer-close-h3-no-error"}
    cases=[case for case in matrix["case_results"] if case["case_id"] in ids]
    source_checks={name:sha(ROOT/name)==digest for name,digest in frozen["file_sha256"].items()}
    receipt={"schema":"uvicorn-rs-held-response-full-proof@1","recorded_at":datetime.now(timezone.utc).isoformat(),"report":str(REPORT.relative_to(ROOT)),"report_sha256":sha(REPORT),"context_sha256":sha(REPORT.with_name(REPORT.name+".context.json")),"status":extension["status"],"matrix":{key:value for key,value in matrix.items() if key!="case_results"},"source":extension["run"]["source"],"build":extension["run"]["build"],"coverage":{key:value for key,value in coverage.items() if key not in ("regions","uncovered_regions")},"frozen_source_matches_report":extension["run"]["source"]==frozen,"frozen_current_file_checks":source_checks,"case_receipts":cases,"drain_regions":[region for region in coverage["regions"] if region["file"]=="src/lib.rs" and region["start"]["line"]==3878 and region["end"]["line"]<=3880],"normal_restored":False}
    OUTPUT.write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"receipt":str(OUTPUT.relative_to(ROOT)),"status":receipt["status"],"summary":{key:matrix[key] for key in ("selected","executed","passed","failed","infrastructure_failed","transient_infrastructure_failures")},"coverage":coverage["summary"],"frozen_current_files_stable":all(source_checks.values()),"native_sha256":receipt["build"]["native_extension_sha256"]}))

if __name__=="__main__":
    main()
