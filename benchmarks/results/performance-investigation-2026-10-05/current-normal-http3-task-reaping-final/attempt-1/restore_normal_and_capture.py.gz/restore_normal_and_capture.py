#!/usr/bin/env python3
"""Restore the verified normal snapshot only after complete source-bound proof."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
GATES = Path(__file__).resolve().parent
PROOF = ROOT / "build/asgi-coverage/unified-http3-owned-request-drain-451-2026-10-05"
REPORT = PROOF / "full-attempt-2/coverage-report.json"
NORMAL = ROOT / "build/performance-2026-10-05/h3-reaping-final-normal/_native.abi3.so"
INSTALLED = ROOT / "python/uvicorn_rs/_native.abi3.so"
SOURCE = "c7bd494d0b11d7aa75ed9d8b64c80e6634966b31a916ae01086bdd2e52b417f7"
NORMAL_SHA = "0e13bb6d56cbccd53b2f34197358563d7fbaa04ad7cac69f359fd1a60d93d19d"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def need(value, reason):
    if not value:
        raise RuntimeError(reason)

def main():
    report = json.loads(REPORT.read_text())["uvicorn_rs_unified"]
    matrix, coverage = report["matrix"], report["coverage"]
    need(matrix["scope"] == "complete", "proof must cover the complete indexed matrix")
    need(matrix["selected"] == matrix["executed"] == matrix["passed"] == 451, "all451 attribution cases must pass")
    need(matrix["failed"] == matrix["infrastructure_failed"] == matrix["transient_infrastructure_failures"] == 0, "attribution must have zero failures/retries")
    need(matrix["case_attribution_complete"] is True, "attribution must be complete")
    repeats = matrix["verification_runs"]
    need(len(repeats) == matrix["verification_runs_required"] == 3, "three full repeats required")
    expected = {"selected":451,"executed":451,"passed":451,"failed":0,"infrastructure_failed":0,"not_run":0}
    for run in repeats:
        need(run["status"] in ("complete", "completed") and run["runner_exit_code"] == 0 and run["summary"] == expected, "every full repeat must pass without failures")
        need(run["transient_infrastructure_failures"] == 0 and len(run["attempts"]) == 1, "zero repeat retries required")
        need(sha(ROOT/run["artifact"]) == run["sha256"], "repeat report changed")
    need(len(matrix["case_results"]) == 451 and all(case["status"] == "passed" and len(case["attempts"]) == 1 and case["transient_infrastructure_failures"] == 0 for case in matrix["case_results"]), "all original attribution attempts must pass")
    need(coverage["gate"] == "passed" and coverage["attribution"]["case_region_ids_verified"] is True and coverage["attribution"]["profile_union_matches_attribution"] is True, "union attribution must be verified")
    need(all(coverage["summary"][metric]["missing"] == 0 for metric in ("regions", "lines")), "LLVM region and line gaps remain")
    mcp = coverage["coverage_mcp"]
    need(mcp["status"] == "measured" and mcp["source"] == "matches_receipt" and mcp["tests"] == "passed" and mcp["group_count"] == 0 and mcp["coverage"]["missing"] == 0, "unfiltered source-bound MCP proof must pass")
    frozen = json.loads((PROOF/"frozen-451-identity.json").read_text())["source_identity"]["file_sha256"]
    need(report["run"]["source"]["file_sha256"] == frozen, "full report differs from frozen451 source/input identity")
    for name, digest in frozen.items():
        need(sha(ROOT/name) == digest, "frozen source changed: " + name)
    need(sha(ROOT/"src/lib.rs") == SOURCE and sha(NORMAL) == NORMAL_SHA, "normal native/source identity mismatch")
    measured = report["run"]["build"]["native_extension_sha256"]
    need(sha(INSTALLED) == measured, "installed instrumented binary differs from full proof")
    saved = GATES/"instrumented-from-successful-full.abi3.so"
    need(not saved.exists(), "fresh normal gate directory required")
    shutil.copy2(INSTALLED, saved)
    need(sha(saved) == measured, "instrumented backup mismatch")
    shutil.copy2(NORMAL, INSTALLED)
    need(sha(INSTALLED) == NORMAL_SHA, "normal installation mismatch")
    receipt={"schema":"uvicorn-rs-normal-restore@1","restored_at":datetime.now(timezone.utc).isoformat(),"full_report":str(REPORT.relative_to(ROOT)),"full_report_sha256":sha(REPORT),"source_sha256":SOURCE,"instrumented_before_sha256":measured,"instrumented_backup":str(saved.relative_to(ROOT)),"saved_normal":str(NORMAL.relative_to(ROOT)),"installed_normal_sha256":sha(INSTALLED),"full_cases":451,"full_repeats":3,"infra_retries":0}
    (GATES/"restore-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    command=[str(ROOT/".venv/bin/python"),str(ROOT/"scripts/run_benchmark_categories.py"),"--capture-identity",str(GATES/"benchmark-identity-before-public-parity.json"),"--expected-source-sha256",SOURCE,"--expected-native-sha256",NORMAL_SHA,"--expected-public-cases","214"]
    with (GATES/"identity-capture.log").open("x") as log:
        process=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=False)
    receipt["capture_command"]=command
    receipt["capture_exit_code"]=process.returncode
    receipt["status"]="normal_restored_identity_captured" if process.returncode == 0 else "normal_restored_capture_failed"
    if process.returncode == 0:
        receipt["portable_identity_sha256"]=sha(GATES/"benchmark-identity-before-public-parity.json")
    (GATES/"restore-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt))
    return process.returncode

if __name__ == "__main__":
    raise SystemExit(main())
