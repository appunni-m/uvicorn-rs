#!/usr/bin/env python3
"""Bind normal public/exclusion proof to the maintained portable identity."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[3]
GATES=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"scripts"))
from benchmark_evidence import BenchmarkEvidence
from run_benchmark_categories import capture_identity,validate_parity

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    before=GATES/"benchmark-identity-before-public-parity.json"
    public=GATES/"public-parity-result.json"
    current=capture_identity(ROOT,ROOT/".venv/bin/python",BenchmarkEvidence)
    gate=validate_parity(ROOT,before,public,current,214)
    exclusion=json.loads((GATES/"receipt.json").read_text())
    assert exclusion["status"]=="passed" and all(value is True for value in exclusion["checks"].values()),"normal exclusion audit must pass every check"
    assert exclusion["source_sha256"]==current["source"]
    assert exclusion["native_extension_sha256"]==current["native"]
    point="http3.request-task.panic-after-response"
    assert point in exclusion["fault_marker_counts"] and exclusion["fault_marker_counts"][point]==0 and exclusion["strings_fault_marker_counts"][point]==0,"post-response point must be explicitly absent"
    result={"schema":"uvicorn-rs-normal-gates-held-response@1","status":"passed","recorded_at":datetime.now(timezone.utc).isoformat(),"source_sha256":current["source"],"normal_native_sha256":current["native"],"portable_identity_exactly_stable":current==json.loads(before.read_text())["identity"],"portable_identity":str(before.relative_to(ROOT)),"portable_identity_sha256":sha(before),"public_parity_gate":gate,"public_summary":json.loads(public.read_text())["summary"],"exclusion_audit":str((GATES/"receipt.json").relative_to(ROOT)),"exclusion_audit_sha256":sha(GATES/"receipt.json"),"exclusion_summary":exclusion["parity"],"registered_fault_point_count":exclusion["registered_fault_point_count"],"post_response_fault_marker_absent":True,"all_exclusion_checks_passed":True,"restore_receipt_sha256":sha(GATES/"restore-receipt.json")}
    assert result["portable_identity_exactly_stable"]
    (GATES/"normal-gates-receipt.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    main()
